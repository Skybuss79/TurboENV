# -*- coding: utf-8 -*-
from .conf import settings  # needed for conf discovery
