__version__ = '0.3'
__description__ = "Absolute URLs tools for django"
