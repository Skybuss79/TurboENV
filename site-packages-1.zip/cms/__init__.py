# -*- coding: utf-8 -*-

__version__ = '3.6.0'

default_app_config = 'cms.apps.CMSConfig'
