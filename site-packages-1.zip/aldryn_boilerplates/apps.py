# -*- coding: utf-8 -*-
from __future__ import absolute_import, unicode_literals

from django.apps import AppConfig


class AldrynBoilerplatesConfig(AppConfig):
    name = 'aldryn_boilerplates'
    verbose_name = "Aldryn Boilerplates"
