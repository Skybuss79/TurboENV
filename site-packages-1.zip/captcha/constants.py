# Test keys as per https://developers.google.com/recaptcha/docs/faq
# "With the following test keys, you will always get No CAPTCHA and all
# verification requests will pass."
TEST_PUBLIC_KEY = "6LeIxAcTAAAAAJcZVRqyHh71UMIEGNQ_MXjiZKhI"
TEST_PRIVATE_KEY = "6LeIxAcTAAAAAGG-vFI1TnRWxMZNFuojJ4WifJWe"
DEFAULT_RECAPTCHA_DOMAIN = "www.google.com"
