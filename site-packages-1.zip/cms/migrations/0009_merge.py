# -*- coding: utf-8 -*-
from __future__ import unicode_literals

from django.db import models, migrations


class Migration(migrations.Migration):

    dependencies = [
        ('cms', '0008_auto_20150121_0059'),
        ('cms', '0008_auto_20150208_2149'),
    ]

    operations = [
    ]
