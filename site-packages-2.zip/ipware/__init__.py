from .ip2 import get_client_ip


default_app_config = 'ipware.apps.IPwareConfig'

__author__ = 'Val Neekman @ Neekware Inc. [@vneekman]'
__description__ = "A Django application to retrieve user's IP address"
__version__ = '2.1.0'
