# -*- coding: utf-8 -*-
class NamespaceAlreadyRegistered(Exception):
    pass


class NoParentFound(Exception):
    pass
