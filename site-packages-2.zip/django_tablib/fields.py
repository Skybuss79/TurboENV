class Field(object):
    def __init__(self, attribute=None, header=None):
        self.attribute = attribute
        self.header = header
